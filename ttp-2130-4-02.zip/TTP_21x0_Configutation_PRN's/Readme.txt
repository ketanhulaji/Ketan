README FILE FOR TTP 21x0 CONFIGUTATION SCRIPTS
==============================================
Please open and read the readme.pdf before trying to use what is in this archive!
